
import React, { useState } from 'react';

function App() {
  const [formData, setFormData] = useState({ lymphatics: 2, block_of_afferent_lymphatics: 2, bl_of_lymph_c: 2, bl_of_lymph_s: 2,
    by_pass: 2, extravasates: 2, regeneration_of_ly: 2, early_uptake_in_ly: 2, lym_nodes_dimin: 2, lym_nodes_enlar: 2,
    changes_in_lym: 1, defect_in_node: 1, changes_in_node: 1, changes_in_stru: 1, special_forms: 1,
    dislocation_of: 1, exclusion_of_no: 1, no_of_nodes_in: 2 });
  const [result, setResult] = useState('');

  const handlePredict = async () => {
    const response = await fetch('/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });
    const data = await response.json();
    setResult(data.prediction || data.error || 'Unknown error');
  };

  return (
    <div><h1>Lymphography Form</h1><button onClick={handlePredict}>Predict</button><p>{result}</p></div>
  );
}

export default App;
