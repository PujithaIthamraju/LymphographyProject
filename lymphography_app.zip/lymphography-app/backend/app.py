
from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib

app = Flask(__name__)
CORS(app)

model = joblib.load("lymphography_model.joblib")

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    try:
        input_data = [[
            data['lymphatics'], data['block_of_afferent_lymphatics'], data['bl_of_lymph_c'],
            data['bl_of_lymph_s'], data['by_pass'], data['extravasates'], data['regeneration_of_ly'],
            data['early_uptake_in_ly'], data['lym_nodes_dimin'], data['lym_nodes_enlar'],
            data['changes_in_lym'], data['defect_in_node'], data['changes_in_node'], data['changes_in_stru'],
            data['special_forms'], data['dislocation_of'], data['exclusion_of_no'], data['no_of_nodes_in']
        ]]
        prediction = model.predict(input_data)
        labels = {
            1: "Class 1: Normal",
            2: "Class 2: Inflamed",
            3: "Class 3: Metastasis",
            4: "Class 4: Malignant"
        }
        return jsonify({'prediction': labels[int(prediction[0])]})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == "__main__":
    app.run(debug=True)
